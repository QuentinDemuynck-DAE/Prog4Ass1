#pragma once

static const float g_fixedTimeStep{ 0.02f };